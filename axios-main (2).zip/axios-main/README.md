# 🚀 Mastering Axios: The Ultimate HTTP Client Guide for Students

Welcome to the world of seamless API communication! **Axios** is one of the most popular, promise-based HTTP clients for modern web development. Whether you're building a sleek React app or a robust Node.js backend, Axios makes handling network requests incredibly simple and powerful.

---

## 🧐 What is Axios?

Axios is a lightweight, promise-based HTTP client that works in both the **browser** and **Node.js**. Think of it as a "supercharged" version of the native `fetch` API. It allows you to send requests to servers and handle responses with ease, while providing a ton of built-in features that save you time and code.

---

## 🔥 Why Choose Axios Over `fetch`?

| Feature | Axios 🚀 | Native Fetch 🌐 |
| :--- | :--- | :--- |
| **JSON Handling** | Automatically parses JSON for you! | Requires an extra `.json()` step. |
| **Error Handling** | Throws errors for any non-2xx status code. | Only throws for network failures (like being offline). |
| **Interceptors** | Built-in! Intercept requests/responses globally. | Requires manual wrappers. |
| **Old Browser Support** | Supports even older browsers like IE11. | Only modern browsers. |
| **Request Cancellation** | Supports AbortController / CancelTokens. | Supported (since recently) but more manual. |

---

## ✨ Key Features Every Student Should Know

-   **Universal**: Works in the browser (XHR) and Node.js (http).
-   **Promise-Based**: Perfect for `async/await` syntax.
-   **Auto-Transformation**: Automatically converts data to JSON/from JSON.
-   **Request & Response Interceptors**: Add headers, log info, or handle errors globally before they reach your code.
-   **XSRF Protection**: Extra security built-in for your peace of mind.

---

## 🛠️ How to Install

Adding Axios to your project is as easy as one command:

### For Node.js/Frameworks (npm or yarn)
```bash
# Using npm
npm install axios

# Using yarn
yarn add axios
```

### For Simple Static Web Pages (CDN)
Include this in your HTML `<head>` or before the closing `</body>` tag:
```html
<script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
```

---

## 👨‍💻 Let's Code! Basic Examples

### 1️⃣ GET Request (Fetching Data)
Retrieve user information from an external API with just a few lines.

```javascript
const axios = require('axios'); // Only if in Node.js

async function fetchUser() {
  try {
    // Axios handles the URL and params beautifully!
    const response = await axios.get('https://jsonplaceholder.typicode.com/users/1');

    // IMPORTANT: Axios puts the data inside the '.data' property
    console.log("User Name:", response.data.name); 
    console.log("Status Code:", response.status);
  } catch (error) {
    console.error("Oops! Something went wrong:", error.message);
  }
}

fetchUser();
```

### 2️⃣ POST Request (Sending Data)
Submit new data, like a new post or user registration.

```javascript
async function createPost() {
  const newPost = {
    title: 'Learning Axios is Fun!',
    body: 'Axios makes APIs easy to manage.',
    userId: 1
  };

  try {
    const response = await axios.post('https://jsonplaceholder.typicode.com/posts', newPost);
    
    // Axios automatically handles the headers (Content-Type: application/json)
    console.log("Post Created Successfully!");
    console.log("New ID:", response.data.id);
  } catch (error) {
    console.error("Error creating post:", error);
  }
}

createPost();
```

---

## ⚡ Pro Tip: Using Interceptors (Advanced Topic)

Imagine you want to add an **API Key** or an **Auth Token** to *every* request you make, without writing it every single time. This is where **Interceptors** shine!

```javascript
// Add a request interceptor
axios.interceptors.request.use(function (config) {
    // Do something before request is sent
    config.headers.Authorization = 'Bearer MY_SECRET_TOKEN';
    console.log("Adding Authorization Header automatically!");
    return config;
  }, function (error) {
    // Do something with request error
    return Promise.reject(error);
});
```

---

## 📝 Summary: Helpful Cheatsheet

| Task | Axios Code |
| :--- | :--- |
| **Install** | `npm install axios` |
| **GET** | `axios.get(url)` |
| **POST** | `axios.post(url, data)` |
| **Response Data** | Found in `response.data` |
| **Error Catching** | Use `try/catch` with `async/await` |

---

### 🎨 Ready to build something amazing? 
Check out the [official Axios documentation](https://axios-http.com/docs/intro) for even more advanced configuration options, custom instances, and concurrency features!